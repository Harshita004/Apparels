const Users = [{
    userId: 1,
    userName: 'Urmila',
    userEmail: 'urmilashirole2001@gmail.com',
    userPwd: 'urmila@123',
    phone: '9876543210',
    address: 'Ajwa Road, Vadodara'
},
{
    userId: 2,
    userName: 'User',
    userEmail: 'user@apparel.com',
    userPwd: 'user@123',
    phone: '9876543210',
    address: 'Ajwa Road, Vadodara'
},
{
    userId: 3,
    userName: 'Admin',
    userEmail: 'admin@gmail.com',
    userPwd: 'admin@123',
    phone: '9876543210',
    address: 'Ajwa Road, Vadodara'
},
{
    userId: 4,
    userName: 'demo',
    userEmail: 'demo@demo',
    userPwd: 'demo',
    phone: '9898989898',
    address: 'vip road, Vadodara' 
},                 
];
export default Users;
