import React from 'react';
import Controller from './Controller';
import 'bootstrap/dist/css/bootstrap.min.css'


const App = () => {
  return (
    <>
    <Controller />
    </>
  )
}


export default App;