const Products = [{
    id: 1,
	image: "images/product1.jpg",
	name: "EYEBOGLER",
	category: "men",
	price:"Rs.247",
	description: "Moisture wicking fabric is quick-drying, ultra-soft & has a soft feel, keeping you comfortable through any athletic activity. Designed for a comfortable experience. Crew-neck provides a nonrestrictive fit; 	short-sleeve allows for a wider range of motion.Perfect for running, workout and training sports and even as an moisture wicking 	undershirt.Raglan sleeves for a sporty lookFamously durable beefy-t fabric"
	},
	
	{
	
	id: 2,
	image: "images/product2.jpg",
	name: "Lymio Casual Shirt",
	category: "men",
	price:"Rs.349",
	description: " casual shirt for men || men stylish shirt Style - Enhance your look by wearing this Casual Stylish Men's shirt, Team it with 	a 	pair of tapered denims Or Solid Chinos and Loafers for a fun Smart Casual 	lookOnly upper part of Only shirt is given Not inner t shirt and No any Accessories 	given Closure Type: Button; Collar Style: Printed"
	},

	{
	
	id: 3,
	image: "images/product3.jpg",
	name: "LEOTUDE",
	category: "men",
	price:"Rs.499",
	description: "Sleeve: Half Sleeve Pattern: Printed Combo Pack of 3 Fabric: Dri-Fit Regular Fit T-shirt, so very comfortable to wear, also looks very trendy & classy"

	},

		{
	
	id: 4,
	image: "images/product4.jpg",
	name: "CB-COLEBROOK ",
	category: "men",
	price:"Rs.499",
	description: "Premium Quality Casual Shirts Collection Eexclusively manufactured by COLEBROOK brand. Long lasting fabric and trendy colors make it evergreen for casual and formal usage. You can use it on jeans as well as it is appropriate as formal office wear. Acurate stitching by skilled workers gives it authentic classic look. You will love to wear it for multi purpose use as shirts boys men, for men look, shirts for men stylish, casual shirt,branded.",

	},

    {
    id: 5,
	image: "images/product5.jpg",
	name: "Leriya Fashion  ",
	category: "men",
	price:"Rs.449",
	description: "Perfect Gift You Can Gift This Shirt to You Friend, Father, Grandfather, Boyfriend on Birthday, Festivals. We Offer the Right Blend of Quality, Style and Value Aimed to Delight Our Customers. Look Like the Professional That You Are with a Clean, Classic Design That Gives You the Comfort Needed for All Occasions, Office Meetings, Business Daily Routine."

	},

    {
	id: 6,
	image: "images/product6.jpg",
	name: "AUSK",
	category: "men",
	price:"Rs.299",
	description: "Shop from a wide range of T-Shirt from AUSK . Perfect for your everyday use, you could pair it with a stylish pair of Jeans or Trousers complete the look."
	},

	{
    id: 7,
	image: "images/product7.jpg",
	name: "Istyle Can Plain Round Neck",
	category: "women",
	price:"Rs.498",
	description: "Breathable fabric keeps you cool and comfortable all day long. Easy to care for - machine washable. Durable fabric that will last you for years to come."
	},

	{
    id: 8,
	image: "images/product8.jpg",
	name: "LEOTUDE Cottonblend Half Sleeve",
	category: "women",
	price:"Rs.298",
	description: "This women's t-shirt is so trendy and cute, you can pair this knot side shirts with jeans and Pants to give a comfy look. Made of soft and breathable cotton blend fabric for comfort and durability"
	},

    {
	id: 9,
	image: "images/product9.jpg",
	name: "TAGAS Women Polycotton Standerd Length Western Top",
	category: "women",
	price:"Rs.449",
	description: "This Top is designed with Western Wear idea's which gives a classy and beautiful look.This top is versatile, comfortable and universally flattering. It is a stunner and makes an everlasting statement whenever you wear it..Fron and Back side with Smocked pattern is best in fit to your skin and fiited very well and gives gorgeous look. With Western FULL Sleeve Patten fitted with elastic on sleeve which gives nice and gracy looks and best fitt to your arms. With weightless cloth with cotton Aster"
	},

    {
	id: 10,
	image: "images/product10.jpg",
	name: "GoSriKi Women's Cotton Blend Embroidered",
	category: "women",
	price:"Rs.589",
	description: "Traditional wear, Casual Wear, party wear, evening wear,Please Click On Brand Name GoSriKi For More Products."
	},

    {
	id: 11,
	image: "images/product11.jpg",
	name: "Women Floral Print Anarkali",
	category: "women",
	price:"Rs.449",
	description: "This set includes: 1 Kurta and 1 Pants with Dupatta || Work : Printed || Neck Style:- Round Neck"
	},


    {
    id: 12,
	image: "images/product12.jpg",
	name: "Women's Kanjivaram Soft Silk Saree ",
	category: "women",
	price:"Rs.1449",
	description: "SGF11 brings you a very nice addition to the wardrobe of every fashionable female, who wants to look Gorgeous and distinct. Shop From a Wide Range Of Silk Saree From SGF11 On Amazon. Ideal Casual, Ceremony, Festival, Wedding for the occasion. Very nice and comfortable clothes for women designed in line with the best international trends.Latest fashion that looks great and stylish on Women's and would make an amazing gift. Note - the color might appear slightly different due to changes in your screen resolution."
	},

    {
	id: 13,
	image: "images/product13.jpg",
	name: "4 YOU DRESSES Beautiful Stylish Dress for Girls",
	category: "kids",
	price:"Rs.295",
	description: "4 YOU brings you complete range of girls’ clothing, with best quality in affordable price, this Dress designed for day long comfort with Creta fabric, this dress has beautiful Color and design, comfort for any occasion any day."
	},

    {
	id: 14,
	image: "images/product14.jpg",
	name: "Wish Karo Baby Girls Knee Length Lycra Dress",
	category: "kids",
	price:"Rs.567",
	description: "Made from skin-friendly Lycra, this dress will sit comfortably on your kid's tender skin without causing any irritation.This party-wear dress has a multi-layer fabric to give it a fluffy look. "
	},
    {
	id: 15,
	image: "images/product15.jpg",
	name: "TAGAS Baby-Girls Dress",
	category: "kids",
	price:"Rs.499",
	description: "This dress are absolutely adorable.Its sleeves are short sleeves that cover just the shoulders, giving a sweet and delicate look to the dress.It is a perfect for special occasions. My little one look super cute in a dress ."
	},

    {
	id: 16,
	image: "images/product16.jpg",
	name: "Bold N Elegant Printed Check Full Sleeve Jacket",
	category: "kids",
	price:"Rs.949",
	description: "What's more, this color matches the personality of our little boys. This eye-catching plaid perfectly depicts the lively and fun-loving nature of your kid."
	},

	{
   	 id: 17,
	image: "images/product17.jpg",
	name: "Hopscotch Boys Overall and Dress Set",
	category: "kids",
	price:"Rs.792",
	description: "We're Hopscotch, India's largest kids’ fashion brand. From playtime to bedtime. From infancy to childhood. And everything in between. We curate the most fashionable and on-trend head-to-toe looks for every kid, every occasion, and every moment of childhood."
	},

	{
   	id: 18,
	image: "images/product18.jpg",
	name: "Hopscotch Boys Overall and Dress Set",
	category: "kids",
	price:"Rs.780",
	description: "We're Hopscotch, India's largest kids’ fashion brand. From playtime to bedtime. From infancy to childhood. And everything in between. We curate the most fashionable and on-trend head-to-toe looks for every kid, every occasion, and every moment of childhood. We bring you what your kids will love and yet be comfortable in by scouring the world and hand-picking aww-some new styles every single day."
	},

	{
	id: 19,
	image: "images/product19.jpg",
	name: "Men Traditional Sherwani",
	category: "traditional",
	price:"Rs.1780",
	description: "Men traditional wear for parties, marriages, functions.Men traditional wear for parties, marriages, functions.Men traditional wear for parties, marriages, functions."
	},

	{
	id: 20,
	image: "images/product20.jpg",
	name: "Women Traditional Lehenga",
	category: "traditional",
	price:"Rs.1520",
	description: "Women traditional wear for Reception, marriages, functions.Men traditional wear for parties, marriages, functions.Men traditional wear for parties, marriages, functions."
	},


];

export default Products;
